// Placeholder for lib/utils.ts
