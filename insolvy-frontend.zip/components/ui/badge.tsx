// Placeholder for components/ui/badge.tsx
